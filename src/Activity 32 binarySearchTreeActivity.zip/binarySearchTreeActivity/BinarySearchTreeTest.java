package binarySearchTreeActivity;

// BinarySearchTreeTest.java
public class BinarySearchTreeTest {
    public static void main(String[] args) {
        BinarySearchTreeDemo.main(args);
    }
}
