<!-- student_record.xml -->
<record>
<student id="1">
<firstname>John</firstname>
<lastname>Doe</lastname>
<major>Computer Science</major>
<gpa>3.8</gpa>
</student>
<student id="2">
<firstname>Jane</firstname>
<lastname>Smith</lastname>
<major>Electrical Engineering</major>
<gpa>3.5</gpa>
</student>
</record>
