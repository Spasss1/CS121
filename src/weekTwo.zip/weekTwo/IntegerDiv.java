package weekTwo;

public class IntegerDiv{
    public static void main(String[] args) {
    //shortcut print
    int numOne = 1;
    int numTwo =4;
    int result1 = numOne/numTwo;

    System.out.print(result1);
    System.out.println();
    double result = (double)(numOne)/numTwo;

    System.out.print(result);

//Strings
    String color = "blue";
    //color.concat(str"red");
    color = color.concat(" red");


    String name = "Helen";

    }
}
